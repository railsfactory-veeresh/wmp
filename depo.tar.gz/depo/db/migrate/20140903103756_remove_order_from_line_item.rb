class RemoveOrderFromLineItem < ActiveRecord::Migration
  def change
  end
end
